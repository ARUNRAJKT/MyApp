import axios from 'axios'
import React, { useEffect, useState } from 'react'
import {Grid,Typography,Modal,Box,Button,TextField} from '@mui/material'
import {DeleteOutline,SystemUpdateAlt,ModeEdit} from '@mui/icons-material/';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'cornflowerblue',
    // border: '2px solid #000',
    boxShadow: 24,
    p: 4,
  };

export default function Fooddonation() {
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const [book,setBook]=useState([])
    const [bookdata,setbookdata]=useState()
    useEffect(()=>{
        axios.get('http://localhost:5000/api/item/view-food').then((response)=>{
            const allbook=response.data.data
            console.table(allbook)
            if (response.data.success==true) {
                setBook(allbook)
                
            }
            console.table(allbook)
        })
    },[])

    // ==Edit==section==

    const Approve=(id)=>{
        console.log(id)
        handleOpen()
        axios.get(`http://localhost:5000/api/item/edit/${id}`).then((response)=>{
            console.log(response)
            setbookdata(response.data.message)
            
        })
    }

    const edit=(e)=>{
      const {name,value}=e.target
      setbookdata({...bookdata,[name]:value})
    }
    
    // ==Updat==book==
    const update=(id)=>{
      axios.post('http://localhost:5000/api/item/update-food').then((response)=>{
        console.log(response)
      })
    }
  return (
    <div className="card">
    <Grid container>
        {/* ===[mapping-section]=== */}
            {book.map((index)=>(   

            <Grid item xs={2}>      
                <div className="books" style={{padding:"10%",lineHeight:"10px"}}> 
                    <Typography className='type' variant='h5'>
                       Category : {index.category}
                    </Typography>
                    <Typography className='type' variant='h5'><br />
                       Language : {index.language}
                    </Typography><br /><br /><br /><br /><br /><br />
                    <Button onClick={()=>Approve(index._id)} variant='contained'><ModeEdit/></Button>
                    <Button variant='contained' style={{float:"right",backgroundColor:"black"}}><DeleteOutline/></Button>
                </div>
                <Modal
        open={open}
        onClose={handleClose}
      >
        <Box sx={style}>
         <TextField variant='filled' label="Category" style={{width:"100%"}} name='category' value={bookdata.category || ""} onChange={edit}></TextField>
         <TextField variant='filled' label="Language" style={{width:"100%",marginTop:"17px"}} name='language' value={bookdata.language || ""} onChange={edit} ></TextField>
         <Button onClick={update()} variant='contained' style={{color:"white",backgroundColor:"black",float:"right",marginTop:"20px",position:"absolute",bottom:"0px",right:"10px"}}><SystemUpdateAlt/>Update</Button>
        </Box>
      </Modal>
            </Grid>
           ))} 
        </Grid>
        {/* [[[==Modal==]]] */}
     
    </div>
  )
}

