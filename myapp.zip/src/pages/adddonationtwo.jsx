import React from 'react'
import Adminnav from '../component/adminnav'
import Clothdonation from '../component/clothdonation'

export default function adddonation() {
  return (
    <React.Fragment>
    <Adminnav/>
    <Clothdonation/>
  </React.Fragment>

  )
}
