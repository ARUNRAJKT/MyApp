
import React from 'react';
import Adminnav from '../component/adminnav';
import Adminfeed from '../component/adminfeed';
export default function admin() {
  return (
    <React.Fragment>
      <Adminnav/>
      <Adminfeed/>
    </React.Fragment>
  )
}
