import React from 'react'
import Adminnav from '../component/adminnav'
import Editbook from '../component/editbook'

export default function bookupdate() {
  return (
    <React.Fragment>
    <Adminnav/>
    <Editbook/>
  </React.Fragment>

  )
}