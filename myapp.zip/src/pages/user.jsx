import React from 'react'
import Userfeed from '../component/userfeed'
import Usernav from '../component/usernav'
export default function user() {
  return (
    <React.Fragment>
        <Usernav/>
        <Userfeed/>
    </React.Fragment>
  )
}
