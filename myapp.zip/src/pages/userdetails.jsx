import React from 'react'
import Adminnav from '../component/adminnav'

import Cards from '../component/cards';

export default function userdetails() {
  return (
    <React.Fragment>
    <Adminnav/>
    <Cards/>
  </React.Fragment>

  )
}
