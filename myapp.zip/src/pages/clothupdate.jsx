import React from 'react'
import Adminnav from '../component/adminnav'

import Editcloth from '../component/editcloth'

export default function clothupdate() {
  return (
    <React.Fragment>
    <Adminnav/>
    <Editcloth/>
  </React.Fragment>

  )
}