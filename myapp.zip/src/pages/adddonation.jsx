import React from 'react'
import Adminnav from '../component/adminnav'
import Fooddonation from '../component/fooddonation'

export default function adddonation() {
  return (
    <React.Fragment>
    <Adminnav/>
    <Fooddonation/>
  </React.Fragment>

  )
}
