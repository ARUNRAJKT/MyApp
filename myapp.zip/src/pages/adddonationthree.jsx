import React from 'react'
import Adminnav from '../component/adminnav'
import Bookdonation from '../component/bookdonation'

export default function adddonation() {
  return (
    <React.Fragment>
    <Adminnav/>
    <Bookdonation/>
  </React.Fragment>

  )
}
